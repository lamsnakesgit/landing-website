#!/bin/bash

if [ -e /usr/local/share/ca-certificates/extra/ ]; 
then 
	echo "Folder already exists"
else
	sudo mkdir /usr/local/share/ca-certificates/extra
fi

sudo cp -a test/*.pem /etc/ssl/certs/

cd test
for f in *.pem; do 
    mv -- "$f" "${f%.pem}.crt"
done
cd ..

sudo cp -a test/*.crt /usr/local/share/ca-certificates/extra/

sudo update-ca-certificates

cd test
for f in *.crt; do 
    mv -- "$f" "${f%.crt}.pem"
done
cd ..
